import{s as e}from"./index-D179fEH3.js";function c(t){return e({url:`/sys/dictData/selectDataByDictTypeCache/${t}`,method:"get"})}export{c as g};
