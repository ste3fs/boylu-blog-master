import{s as e}from"./index-wFkX9j74.js";function c(t){return e({url:`/sys/dictData/selectDataByDictTypeCache/${t}`,method:"get"})}export{c as g};
