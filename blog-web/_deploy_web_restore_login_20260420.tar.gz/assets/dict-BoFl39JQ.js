import{s as e}from"./index-6dqy4sFR.js";function c(t){return e({url:`/sys/dictData/selectDataByDictTypeCache/${t}`,method:"get"})}export{c as g};
