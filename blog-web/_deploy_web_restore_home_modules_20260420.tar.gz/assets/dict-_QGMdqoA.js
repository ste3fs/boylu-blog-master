import{s as e}from"./index-DVSuMLvg.js";function c(t){return e({url:`/sys/dictData/selectDataByDictTypeCache/${t}`,method:"get"})}export{c as g};
