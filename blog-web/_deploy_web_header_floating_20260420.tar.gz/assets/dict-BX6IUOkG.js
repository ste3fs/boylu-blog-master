import{s as e}from"./index-CW_b-XmO.js";function c(t){return e({url:`/sys/dictData/selectDataByDictTypeCache/${t}`,method:"get"})}export{c as g};
