import{_ as o}from"./DictData.vue_vue_type_script_setup_true_lang-1e2ecd0b.js";import"./index-4ac5d87a.js";import"./dict-63f86f0c.js";export{o as default};
