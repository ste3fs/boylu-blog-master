import{_ as o}from"./DictData.vue_vue_type_script_setup_true_lang-d9a979e0.js";import"./index-0676e7c1.js";import"./dict-1036061d.js";export{o as default};
